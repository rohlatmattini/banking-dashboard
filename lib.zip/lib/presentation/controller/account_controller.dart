import 'package:get/get.dart';
import 'package:flutter/material.dart';
import '../../domain/entities/account_entity.dart';
import '../../domain/repositories/account_repository.dart';
import '../../domain/dtos/open_account_dto.dart';
import '../../domain/enums/account_type_enum.dart';
import '../helpers/state_helper.dart';

class AccountController extends GetxController {
  final AccountRepository repository;

  AccountController({required this.repository});

  final accounts = <AccountEntity>[].obs;
  final isLoading = true.obs;
  final selectedAccount = Rxn<AccountEntity>();
  final RxInt currentUserId = 13.obs;
  // final RxString publicId = "cc164d4f-2363-43de-8bef-b99ca75ee6ea".obs;

  @override
  void onInit() {
 //   fetchAccounts();
    super.onInit();
  }
  Future<void> createUserAccount(OpenAccountData data) async {
    try {
      isLoading.value = true;

      final newAccount = await repository.createUserAccount(
        userId: currentUserId.value,
        type: data.type,
        dailyLimit: data.dailyLimit,
        monthlyLimit: data.monthlyLimit,
      );

      accounts.add(newAccount);
      _showSuccess('تم إنشاء الحساب بنجاح');

      // تحديث القائمة بعد الإنشاء
   //   await fetchAccounts();
    } catch (e) {
      _showError('فشل إنشاء الحساب', e.toString());
    } finally {
      isLoading.value = false;
    }
  }

  // قم بتعديل دالة createAccount القديمة لاستخدام الطريقة الجديدة
  Future<void> createAccount(OpenAccountData data) async {
    // استخدم الطريقة الجديدة مباشرة
    await createUserAccount(data);
  }

  // Future<void> fetchAccounts() async {
  //   isLoading.value = true;
  //   try {
  //     final result = await repository.listByUser(currentUserId.value);
  //     accounts.assignAll(result);
  //   } catch (e) {
  //     _showError('فشل تحميل الحسابات', e.toString());
  //   } finally {
  //     isLoading.value = false;
  //   }
  // }

  Future<void> changeAccountState(String publicId, String newState) async {
    try {
      final account = accounts.firstWhere((acc) => acc.publicId == publicId);

      // Validate state transition
      if (!account.canTransitionTo(newState)) {
        throw Exception(account.transitionError(newState));
      }

      isLoading.value = true;

      // Update via repository
      final updated = await repository.updateStateByPublicId(publicId, newState);

      // Update local list
      final index = accounts.indexWhere((acc) => acc.publicId == publicId);
      if (index != -1) {
        accounts[index] = updated;
      }

      _showSuccess('Account status changed successfully');
    } catch (e) {
      _showError('Failed to change account status', e.toString());
    } finally {
      isLoading.value = false;
    }
  }

  void selectAccount(String publicId) {
    selectedAccount.value = accounts.firstWhere((acc) => acc.publicId == publicId);
  }

  Map<String, int> getAccountStatistics() {
    Map<String, int> stats = {
      'total': accounts.length,
      'active': 0,
      'frozen': 0,
      'suspended': 0,
      'closed': 0,
    };

    for (var account in accounts) {
      switch (account.state.name) {
        case 'active':
          stats['active'] = stats['active']! + 1;
          break;
        case 'frozen':
          stats['frozen'] = stats['frozen']! + 1;
          break;
        case 'suspended':
          stats['suspended'] = stats['suspended']! + 1;
          break;
        case 'closed':
          stats['closed'] = stats['closed']! + 1;
          break;
      }
    }

    return stats;
  }

  void _showSuccess(String message) {
    Get.snackbar(
      'نجاح',
      message,
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: Colors.green,
      colorText: Colors.white,
    );
  }

  void _showError(String title, String message) {
    Get.snackbar(
      title,
      message,
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: Colors.red,
      colorText: Colors.white,
    );
  }
}