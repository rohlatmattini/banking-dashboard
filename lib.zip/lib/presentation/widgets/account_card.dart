import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../domain/entities/account_entity.dart';
import '../controller/account_controller.dart';
import '../helpers/state_helper.dart';
import '../widgets/create_account_dialog.dart';
import '../../domain/dtos/open_account_dto.dart';
import '../../domain/enums/account_type_enum.dart';

class AccountCard extends StatelessWidget {
  final AccountEntity account;
  final AccountController controller;

  const AccountCard({
    super.key,
    required this.account,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    final statusColor = StateHelper.getColorForState(account.state);
    final statusIcon = StateHelper.getIconForState(account.state);

    return Card(
      elevation: 3,
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header with Add Account button
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 4),
                      Text(
                        account.holderName,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Icon(Icons.fingerprint, size: 12, color: Colors.grey.shade600),
                          const SizedBox(width: 4),
                          Text(
                            'ID: ${account.publicId}',
                            style: TextStyle(
                              fontSize: 11,
                              color: Colors.grey.shade600,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Row(
                      children: [
                        // Add Account Button
                        IconButton(
                          icon: const Icon(Icons.add_circle, color: Colors.teal, size: 20),
                          onPressed: () => _showCreateAccountDialog(context),
                          tooltip: 'Add Another Account',
                        ),
                        Chip(
                          label: Text(
                            account.type.englishName,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 11,
                            ),
                          ),
                          backgroundColor: Colors.teal,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 2,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(Icons.calendar_today, size: 10, color: Colors.grey.shade600),
                        const SizedBox(width: 4),
                        Text(
                          '${account.createdAt.day}/${account.createdAt.month}/${account.createdAt.year}',
                          style: TextStyle(
                            fontSize: 10,
                            color: Colors.grey.shade600,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),

            const Divider(height: 20, thickness: 1),

            // Balance and Info
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Current Balance:',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey,
                        ),
                      ),
                      Text(
                        '\$${account.balance.toStringAsFixed(2)}',
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.teal,
                        ),
                      ),
                    ],
                  ),
                ),
                if (account.dailyLimit != null || account.monthlyLimit != null)
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      if (account.dailyLimit != null)
                        Row(
                          children: [
                            Icon(Icons.today, size: 12, color: Colors.grey.shade600),
                            const SizedBox(width: 4),
                            Text(
                              'Daily: \$${account.dailyLimit}',
                              style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
                            ),
                          ],
                        ),
                      if (account.monthlyLimit != null)
                        Row(
                          children: [
                            Icon(Icons.calendar_month, size: 12, color: Colors.grey.shade600),
                            const SizedBox(width: 4),
                            Text(
                              'Monthly: \$${account.monthlyLimit}',
                              style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
                            ),
                          ],
                        ),
                    ],
                  ),
              ],
            ),

            const SizedBox(height: 16),

            // State and Actions
            _buildStateAndActionsSection(statusColor, statusIcon),
          ],
        ),
      ),
    );
  }


  void _showCreateAccountDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => CreateAccountDialog(
        onCreate: ({
          required AccountTypeEnum type,
          String? dailyLimit,
          String? monthlyLimit,
        }) {
          final dto = OpenAccountData(
            type: type,
            dailyLimit: dailyLimit,
            monthlyLimit: monthlyLimit,
          );

          controller.createAccount(dto);
        },
      ),
    );
  }


  Widget _buildStateAndActionsSection(Color statusColor, IconData statusIcon) {
    return Column(
      children: [
        // State Info
        Row(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: statusColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: statusColor.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  Icon(statusIcon, color: Colors.teal, size: 14),
                  const SizedBox(width: 6),
                  Text(
                    'Status: ${account.state.englishName}',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      color: Colors.teal,
                    ),
                  ),
                ],
              ),
            ),
            const Spacer(),
            if (account.state.canChangeState)
              IconButton(
                icon: Icon(Icons.sync, color: Colors.teal, size: 20),
                onPressed: () => _showStateChangeDialog(),
                tooltip: 'Change Status',
              ),
          ],
        ),

        const SizedBox(height: 12),

        // Operations - Changed colors to grey
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            _buildOperationButton(
              'Deposit',
              account.state.canDeposit,
              Icons.add,
              Colors.teal,
                  () => _showOperationDialog('deposit'),
            ),
            _buildOperationButton(
              'Withdraw',
              account.state.canWithdraw,
              Icons.remove,
              Colors.teal,
                  () => _showOperationDialog('withdraw'),
            ),
            _buildOperationButton(
              'Transfer',
              account.state.canTransfer,
              Icons.swap_horiz,
              Colors.teal,
                  () => _showTransferDialog(),
            ),

            if (account.state.canClose)
              _buildOperationButton(
                'Close',
                true,
                Icons.lock,
                Colors.teal,
                    () => _confirmCloseAccount(),
              ),
          ],
        ),

        const SizedBox(height: 8),
      ],
    );
  }

  Widget _buildOperationButton(
      String label,
      bool enabled,
      IconData icon,
      Color color,
      VoidCallback onPressed,
      ) {
    return ElevatedButton.icon(
      onPressed: enabled ? onPressed : null,
      icon: Icon(icon, size: 16),
      label: Text(label, style: const TextStyle(fontSize: 12)),
      style: ElevatedButton.styleFrom(
        backgroundColor: enabled ? color : Colors.grey[300],
        foregroundColor: enabled ? Colors.white : Colors.grey[500],
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        minimumSize: const Size(0, 32),
      ),
    );
  }

  void _showStateChangeDialog() {
    final List<Map<String, dynamic>> availableStates = [];

    // Add available states based on current state
    if (account.canTransitionTo('active')) {
      availableStates.add({
        'name': 'active',
        'english': 'Activate',
        'description': 'Make account active',
        'icon': Icons.check_circle,
        'color': Colors.teal,
      });
    }

    if (account.canTransitionTo('frozen')) {
      availableStates.add({
        'name': 'frozen',
        'english': 'Freeze',
        'description': 'Only deposits allowed',
        'icon': Icons.ac_unit,
        'color': Colors.teal,
      });
    }

    if (account.canTransitionTo('suspended')) {
      availableStates.add({
        'name': 'suspended',
        'english': 'Suspend',
        'description': 'All operations paused',
        'icon': Icons.pause_circle,
        'color': Colors.teal,
      });
    }

    if (account.canTransitionTo('closed')) {
      availableStates.add({
        'name': 'closed',
        'english': 'Close',
        'description': 'Close account permanently',
        'icon': Icons.cancel,
        'color': Colors.teal,
      });
    }

    Get.bottomSheet(
      Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20),
            topRight: Radius.circular(20),
          ),
        ),
        padding: const EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Change Account Status',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Account: ${account.holderName}',
                style: const TextStyle(color: Colors.grey),
              ),
              Text(
                'Current Status: ${account.state.englishName}',
                style: const TextStyle(color: Colors.grey),
              ),
              const SizedBox(height: 20),

              if (availableStates.isEmpty)
                const Center(
                  child: Column(
                    children: [
                      Icon(Icons.block, size: 60, color: Colors.grey),
                      SizedBox(height: 16),
                      Text('No available statuses to change'),
                    ],
                  ),
                )
              else ...[
                const Text(
                  'Choose New Status:',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),

                ...availableStates.map((state) =>
                    _buildStateOption(
                      state['english'],
                      state['description'],
                      state['icon'],
                      state['color'],
                      state['name'],
                    ),
                ),
              ],

              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: Get.back,
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.teal,
                  ),
                  child: const Text('Cancel'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStateOption(String title, String subtitle, IconData icon, Color color, String state) {
    return ListTile(
      leading: Icon(icon, color: color),
      title: Text(title),
      subtitle: Text(subtitle),
      onTap: () {
        Get.back();
        controller.changeAccountState(account.publicId, state);
      },
      tileColor: color.withOpacity(0.05),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
        side: BorderSide(color: color.withOpacity(0.2)),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
    );
  }

  void _showOperationDialog(String operation) {
    final amountController = TextEditingController();
    final formKey = GlobalKey<FormState>();

    final isDeposit = operation == 'deposit';
    final title = isDeposit ? 'Deposit' : 'Withdraw';

    Get.dialog(
      AlertDialog(
        title: Text(title),
        content: Form(
          key: formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Account: ${account.holderName}', style: const TextStyle(color: Colors.teal)),
              Text('Current Balance: \$${account.balance.toStringAsFixed(2)}'),
              const SizedBox(height: 16),
              TextFormField(
                controller: amountController,
                cursorColor: Colors.teal,
                decoration: InputDecoration(
                  labelText: 'Amount',
                  prefixIcon: Icon(Icons.attach_money, color: Colors.grey.shade600),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  focusedBorder: const OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.teal),
                  ),
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter amount';
                  }
                  final amount = double.tryParse(value);
                  if (amount == null || amount <= 0) {
                    return 'Please enter a valid amount greater than zero';
                  }
                  if (!isDeposit && amount > account.balance) {
                    return 'Amount is greater than available balance';
                  }
                  return null;
                },
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: Get.back,
            style: TextButton.styleFrom(
              foregroundColor: Colors.teal,
            ),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              if (formKey.currentState!.validate()) {
                final amount = double.parse(amountController.text);
                Get.back();

                // Note: In real app, call use case for deposit/withdraw
                Get.snackbar(
                  'Success',
                  '${isDeposit ? 'Deposited' : 'Withdrawn'} \$${amount.toStringAsFixed(2)}',
                  snackPosition: SnackPosition.BOTTOM,
                  backgroundColor: Colors.teal,
                  colorText: Colors.white,
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.teal,
              foregroundColor: Colors.white,
            ),
            child: Text('Execute $title'),
          ),
        ],
      ),
    );
  }

  void _showTransferDialog() {
    final amountController = TextEditingController();
    final targetAccountController = TextEditingController();
    final formKey = GlobalKey<FormState>();

    Get.dialog(
      AlertDialog(
        title: const Text('Transfer Between Accounts'),
        content: Form(
          key: formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('From: ${account.holderName}', style: const TextStyle(color: Colors.teal)),
              Text('Balance: \$${account.balance.toStringAsFixed(2)}'),
              const SizedBox(height: 16),
              TextFormField(
                controller: amountController,
                cursorColor: Colors.teal,
                decoration: InputDecoration(
                  labelText: 'Amount',
                  prefixIcon: Icon(Icons.attach_money, color: Colors.grey.shade600),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  focusedBorder: const OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.teal),
                  ),
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) return 'Please enter amount';
                  final amount = double.tryParse(value);
                  if (amount == null || amount <= 0) return 'Invalid amount';
                  if (amount > account.balance) return 'Insufficient balance';
                  return null;
                },
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: targetAccountController,
                cursorColor: Colors.teal,
                decoration: InputDecoration(
                  labelText: 'Target Account Number',
                  prefixIcon: Icon(Icons.account_balance, color: Colors.grey.shade600),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  focusedBorder: const OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.teal),
                  ),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) return 'Please enter account number';
                  return null;
                },
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: Get.back,
            style: TextButton.styleFrom(
              foregroundColor: Colors.teal,
            ),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              if (formKey.currentState!.validate()) {
                Get.back();
                Get.snackbar(
                  'Success',
                  'Transfer process started',
                  snackPosition: SnackPosition.BOTTOM,
                  backgroundColor: Colors.teal,
                  colorText: Colors.white,
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.teal,
              foregroundColor: Colors.white,
            ),
            child: const Text('Transfer'),
          ),
        ],
      ),
    );
  }

  void _confirmCloseAccount() {
    Get.defaultDialog(
      title: 'Confirm Close',
      middleText: 'Are you sure you want to close account ${account.holderName}?\n'
          'After closing, the account cannot be reactivated.',
      textConfirm: 'Yes, Close',
      textCancel: 'Cancel',
      confirmTextColor: Colors.white,
      onConfirm: () {
        Get.back();
        controller.changeAccountState(account.publicId, 'closed');
      },
    );
  }


}