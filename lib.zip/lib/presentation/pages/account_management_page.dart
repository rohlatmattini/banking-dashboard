import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../domain/entities/account_entity.dart';
import '../controller/account_controller.dart';
import '../widgets/account_card.dart';
import '../widgets/create_account_dialog.dart';
import '../../domain/dtos/open_account_dto.dart';
import '../../domain/enums/account_type_enum.dart';

class AccountManagementPage extends StatelessWidget {
  final AccountController controller = Get.find<AccountController>();

  AccountManagementPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Manage Accounts',
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: Colors.teal[700],
        elevation: 2,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            icon: const Icon(Icons.person_add, color: Colors.white),
            onPressed: () => Get.toNamed('/accounts/onboard'),
            tooltip: 'Add New Customer',
          ),
          IconButton(
            icon: const Icon(Icons.account_tree, color: Colors.white),
            onPressed: _showAccountTree,
            tooltip: 'Show Tree',
          ),
        ],
      ),
      body: Obx(() {
        if (controller.isLoading.value) {
          return const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircularProgressIndicator(color: Colors.teal),
                SizedBox(height: 16),
                Text('Loading accounts...'),
              ],
            ),
          );
        }

        if (controller.accounts.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.account_balance_wallet,
                  size: 100,
                  color: Colors.grey[300],
                ),
                const SizedBox(height: 20),
                const Text(
                  'No accounts',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey,
                  ),
                ),

              ]
            )
          );
        }

        return const _AccountManagementContent();
      }),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showCreateAccountDialog(context),
        icon: const Icon(Icons.add),
        label: const Text('New Account'),
        backgroundColor: Colors.teal,
      ),
    );
  }

  void _showCreateAccountDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => CreateAccountDialog(
        onCreate:
            ({
          required AccountTypeEnum type,
          String? dailyLimit,
          String? monthlyLimit,
        }) {
          final dto = OpenAccountData(
            type: type,
            dailyLimit: dailyLimit,
            monthlyLimit: monthlyLimit,
          );

          controller.createAccount(dto);
        },
      ),
    );
  }

  void _showAccountTree() {
    Get.defaultDialog(
      title: 'Account Tree',
      content: const Column(
        children: [
          Icon(Icons.account_tree, size: 60, color: Colors.teal),
          SizedBox(height: 16),
          Text('Tree view feature is under development'),
          Text('You will be able to see Group and sub-accounts'),
        ],
      ),
      textConfirm: 'OK',
      onConfirm: Get.back,
    );
  }
}

class _AccountManagementContent extends StatefulWidget {
  const _AccountManagementContent();

  @override
  State<_AccountManagementContent> createState() => _AccountManagementContentState();
}

class _AccountManagementContentState extends State<_AccountManagementContent> {
  String _selectedFilter = 'all';
  String _searchQuery = '';

  List<AccountEntity> get filteredAccounts {
    final controller = Get.find<AccountController>();
    var filtered = controller.accounts.toList();

    // Filter by search text
    if (_searchQuery.isNotEmpty) {
      filtered = filtered.where((account) {
        return account.holderName.toLowerCase().contains(
          _searchQuery.toLowerCase(),
        ) ||
            account.publicId.toLowerCase().contains(
              _searchQuery.toLowerCase(),
            ) ||
            account.type.englishName.toLowerCase().contains(
              _searchQuery.toLowerCase(),
            );
      }).toList();
    }

    // Filter by status
    if (_selectedFilter != 'all') {
      filtered = filtered.where((account) {
        return account.state.name == _selectedFilter;
      }).toList();
    }

    return filtered;
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<AccountController>();
    final stats = controller.getAccountStatistics();

    return Column(
      children: [
        // Account Statistics
        _buildStatisticsCard(stats),

        // Search and Filters
        _buildSearchAndFilters(),

        // Accounts List
        Expanded(
          child: RefreshIndicator(
            onRefresh: () async {},
            child: Obx(() {
              final accountsToShow = filteredAccounts;

              if (accountsToShow.isEmpty) {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        _searchQuery.isNotEmpty || _selectedFilter != 'all'
                            ? Icons.search_off
                            : Icons.account_balance_wallet,
                        size: 80,
                        color: Colors.grey[300],
                      ),
                      const SizedBox(height: 16),
                      Text(
                        accountsToShow.isEmpty && controller.accounts.isNotEmpty
                            ? 'No matching accounts found'
                            : 'No accounts',
                        style: const TextStyle(
                          fontSize: 16,
                          color: Colors.grey,
                        ),
                      ),
                      const SizedBox(height: 8),
                      if (_searchQuery.isNotEmpty || _selectedFilter != 'all')
                        ElevatedButton(
                          onPressed: () {
                            setState(() {
                              _searchQuery = '';
                              _selectedFilter = 'all';
                            });
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.teal,
                            foregroundColor: Colors.white,
                          ),
                          child: const Text('Clear Filters'),
                        ),
                    ],
                  ),
                );
              }

              return ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: accountsToShow.length,
                itemBuilder: (context, index) {
                  final account = accountsToShow[index];
                  return AccountCard(
                    account: account,
                    controller: controller,
                  );
                },
              );
            }),
          ),
        ),
      ],
    );
  }

  Widget _buildStatisticsCard(Map<String, int> stats) {
    return Card(
      margin: const EdgeInsets.all(16),
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Account Statistics',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                Chip(
                  label: Text(
                    '${stats['total']} account${stats['total'] != 1 ? 's' : ''}',
                    style: const TextStyle(color: Colors.white),
                  ),
                  backgroundColor: Colors.teal,
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildStatItem('Active', stats['active'] ?? 0, Colors.teal),
                _buildStatItem('Frozen', stats['frozen'] ?? 0, Colors.teal),
                _buildStatItem(
                  'Suspended',
                  stats['suspended'] ?? 0,
                  Colors.teal,
                ),
                _buildStatItem('Closed', stats['closed'] ?? 0, Colors.teal),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(String label, int value, Color color) {
    return Column(
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: color.withOpacity(0.3)),
          ),
          child: Center(
            child: Text(
              value.toString(),
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ),
        ),
        const SizedBox(height: 4),
        Text(label, style: const TextStyle(fontSize: 12, color: Colors.grey)),
      ],
    );
  }

  Widget _buildSearchAndFilters() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
        children: [
          const SizedBox(width: 8),
          PopupMenuButton<String>(
            icon: Icon(
              Icons.filter_list,
              color: _selectedFilter != 'all' ? Colors.teal : Colors.grey,
            ),
            onSelected: (filter) {
              setState(() {
                _selectedFilter = filter;
              });
            },
            itemBuilder: (context) => [
              PopupMenuItem(
                value: 'all',
                child: Row(
                  children: [
                    _selectedFilter == 'all'
                        ? const Icon(Icons.check, color: Colors.teal, size: 20)
                        : const SizedBox(width: 20),
                    const SizedBox(width: 8),
                    const Text('All Accounts'),
                  ],
                ),
              ),
              PopupMenuItem(
                value: 'active',
                child: Row(
                  children: [
                    _selectedFilter == 'active'
                        ? const Icon(Icons.check, color: Colors.teal, size: 20)
                        : const SizedBox(width: 20),
                    const SizedBox(width: 8),
                    const Text('Active Accounts'),
                  ],
                ),
              ),
              PopupMenuItem(
                value: 'frozen',
                child: Row(
                  children: [
                    _selectedFilter == 'frozen'
                        ? const Icon(Icons.check, color: Colors.teal, size: 20)
                        : const SizedBox(width: 20),
                    const SizedBox(width: 8),
                    const Text('Frozen Accounts'),
                  ],
                ),
              ),
              PopupMenuItem(
                value: 'suspended',
                child: Row(
                  children: [
                    _selectedFilter == 'suspended'
                        ? const Icon(Icons.check, color: Colors.teal, size: 20)
                        : const SizedBox(width: 20),
                    const SizedBox(width: 8),
                    const Text('Suspended Accounts'),
                  ],
                ),
              ),
              PopupMenuItem(
                value: 'closed',
                child: Row(
                  children: [
                    _selectedFilter == 'closed'
                        ? const Icon(Icons.check, color: Colors.teal, size: 20)
                        : const SizedBox(width: 20),
                    const SizedBox(width: 8),
                    const Text('Closed Accounts'),
                  ],
                ),
              ),
            ],
          ),
        ],
      );

  }
}