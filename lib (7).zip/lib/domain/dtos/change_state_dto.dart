class ChangeStateData {
  final String targetState;

  ChangeStateData({required this.targetState});
}