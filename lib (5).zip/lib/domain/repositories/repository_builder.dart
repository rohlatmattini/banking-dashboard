import '../../data/datasource/api_account_data_source.dart';
import '../../data/repositories/account_repository_impl.dart';
import '../patterns/decorators/caching_account_repository.dart';
import '../patterns/decorators/error_handling_account_repository.dart';
import '../patterns/decorators/logging_account_repository.dart';

import '../../domain/repositories/account_repository.dart';
import '../../presentation/helpers/logger.dart';

class RepositoryBuilder {
  static AccountRepository buildAccountRepository() {
    final apiDataSource = ApiAccountDataSource();

    final baseRepository = AccountRepositoryImpl(dataSource: apiDataSource);


    AccountRepository decoratedRepository = ErrorHandlingAccountRepository(baseRepository);

    decoratedRepository = CachingAccountRepository(
      decoratedRepository,
      cacheDuration: const Duration(minutes: 10),
    );

    decoratedRepository = LoggingAccountRepository(decoratedRepository, Logger());

    return decoratedRepository;
  }
}