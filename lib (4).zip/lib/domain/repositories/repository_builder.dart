// lib/data/repositories/repository_builder.dart
import '../../data/datasource/api_account_data_source.dart';
import '../../data/repositories/account_repository_impl.dart';
import '../patterns/decorators/caching_account_repository.dart';
import '../patterns/decorators/error_handling_account_repository.dart';
import '../patterns/decorators/logging_account_repository.dart';

import '../../domain/repositories/account_repository.dart';
import '../../presentation/helpers/logger.dart';

class RepositoryBuilder {
  static AccountRepository buildAccountRepository() {
    // 1. إنشاء DataSource الأساسي
    final apiDataSource = ApiAccountDataSource();

    // 2. إنشاء الـ Repository الأساسي
    final baseRepository = AccountRepositoryImpl(dataSource: apiDataSource);

    // 3. تطبيق الديكورات بالترتيب الصحيح

    // أولاً: Error Handling (يجب أن يكون الأعمق)
    AccountRepository decoratedRepository = ErrorHandlingAccountRepository(baseRepository);

    // ثانياً: Caching
    decoratedRepository = CachingAccountRepository(
      decoratedRepository,
      cacheDuration: const Duration(minutes: 10),
    );

    // ثالثاً: Logging (يجب أن يكون الخارجي)
    decoratedRepository = LoggingAccountRepository(decoratedRepository, Logger());

    return decoratedRepository;
  }
}