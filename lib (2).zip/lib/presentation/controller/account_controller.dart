// lib/presentation/controller/account_controller.dart
import 'package:get/get.dart';
import 'package:flutter/material.dart';
import '../../domain/entities/account_entity.dart';
import '../../domain/repositories/account_repository.dart';
import '../../domain/dtos/open_account_dto.dart';
import '../../domain/enums/account_type_enum.dart';

class AccountController extends GetxController {
  final AccountRepository repository;

  AccountController({required this.repository});

  final usersWithAccounts = <Map<String, dynamic>>[].obs;
  final isLoading = true.obs;
  final selectedAccount = Rxn<AccountEntity>();
  final selectedUserId = Rxn<int>();

  @override
  void onInit() {
    fetchUsersWithAccounts();
    super.onInit();
  }

  Future<void> fetchUsersWithAccounts() async {
    isLoading.value = true;
    try {
      final result = await repository.getUsersWithAccounts();
      usersWithAccounts.assignAll(result);
    } catch (e) {
      _showError('فشل تحميل المستخدمين', e.toString());
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> createUserAccount(int userId, OpenAccountData data) async {
    try {
      isLoading.value = true;

      final newAccount = await repository.createUserAccount(
        userId: userId,
        type: data.type,
        dailyLimit: data.dailyLimit,
        monthlyLimit: data.monthlyLimit,
      );

      // تحديث القائمة بعد الإنشاء
      await fetchUsersWithAccounts();

      _showSuccess('تم إنشاء الحساب بنجاح');
    } catch (e) {
      _showError('فشل إنشاء الحساب', e.toString());
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> changeAccountState(String publicId, String newState) async {
    try {
      isLoading.value = true;

      // Update via repository
      final updated = await repository.updateStateByPublicId(publicId, newState);

      // تحديث القائمة
      await fetchUsersWithAccounts();

      _showSuccess('Account status changed successfully');
    } catch (e) {
      _showError('Failed to change account status', e.toString());
    } finally {
      isLoading.value = false;
    }
  }

  void selectUserId(int userId) {
    selectedUserId.value = userId;
  }

  void _showSuccess(String message) {
    Get.snackbar(
      'نجاح',
      message,
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: Colors.green,
      colorText: Colors.white,
    );
  }

  void _showError(String title, String message) {
    Get.snackbar(
      title,
      message,
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: Colors.red,
      colorText: Colors.white,
    );
  }

  // دالة مساعدة للحصول على إحصائيات
  Map<String, int> getUserStatistics(Map<String, dynamic> userData) {
    final accounts = List<Map<String, dynamic>>.from(userData['accounts'] ?? []);

    Map<String, int> stats = {
      'total': accounts.length,
      'active': 0,
      'frozen': 0,
      'suspended': 0,
      'closed': 0,
    };

    for (var account in accounts) {
      final state = account['state'] as String? ?? 'active';
      switch (state) {
        case 'active':
          stats['active'] = stats['active']! + 1;
          break;
        case 'frozen':
          stats['frozen'] = stats['frozen']! + 1;
          break;
        case 'suspended':
          stats['suspended'] = stats['suspended']! + 1;
          break;
        case 'closed':
          stats['closed'] = stats['closed']! + 1;
          break;
      }
    }

    return stats;
  }
}